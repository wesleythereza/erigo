'use strict';
// Proteção dos resultados publicados: exige saída explícita e recusa qualquer caminho dentro de results/
const path = require('path');
module.exports = function outputPath(p, usage) {
  if (!p) { console.error(`uso: ${usage}\n(o arquivo de saída é obrigatório; use runs/<RUN_ID>/...)`); process.exit(1); }
  const rel = path.relative(path.resolve(__dirname, 'results'), path.resolve(p));
  if (rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel))) {
    console.error(`recusado: ${p} está em results/, que guarda os resultados publicados`); process.exit(1);
  }
  return p;
};
