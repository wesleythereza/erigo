import sys, os
from outguard import run_dir
D = run_dir('python3 analysis.py runs/<RUN_ID>')
# Análise v2: agregação por execução, estatística V2×V3, tabelas e figura
import json, collections, numpy as np
from scipy.stats import mannwhitneyu
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator, FixedFormatter, NullLocator, FuncFormatter

R = [json.loads(l) for l in open(f'{D}/raw.jsonl')]
G = collections.defaultdict(list)
for r in R:
    G[(r['scenario'], r['param'], r['variant'], r['n'])].append(r)

def agg(v):
    a = lambda k: np.array([x[k] for x in v if x[k] is not None], dtype=float)
    out = dict(reps=len(v))
    for k in ['scheduled', 'started', 'acceptedLocalOrUser', 'confirmedServer', 'lost', 'lostSilent', 'lostNotified', 'duplicates', 'outOfOrder', 'requests', 'kills']:
        x = a(k); out[k] = dict(mean=float(x.mean()), min=float(x.min()), max=float(x.max()))
    x = np.array([x['serverNotUser'] for x in v if x['serverNotUser'] is not None], dtype=float)
    out['serverNotUser'] = dict(mean=float(x.mean()), min=float(x.min()), max=float(x.max())) if len(x) else None
    for k in ['drainMs', 'drainAfterGenMs', 'latP50', 'latP95']:
        x = a(k); out[k] = dict(median=float(np.median(x)), min=float(x.min()), max=float(x.max())) if len(x) else None
    pr = [x['procMsTotal'] / x['recordsIn'] for x in v if x['recordsIn']]
    out['procMsPerRecord'] = dict(median=float(np.median(pr)), min=float(min(pr)), max=float(max(pr))) if pr else None
    out['lostPct'] = [100 * x['lost'] / max(x['started'], 1) for x in v]
    out['seqComplete'] = all(x['seqComplete'] for x in v)
    out['finished'] = sum(x['finished'] for x in v)
    return out

S = {'|'.join(map(str, k)): agg(v) for k, v in G.items()}

# comparação V2 × V3 (custo da idempotência): Mann-Whitney bilateral e diferença de medianas com IC bootstrap 95%
rng = np.random.default_rng(20260915)
def compare(metric, scen, param, n):
    a = [x for x in G[(scen, param, 'queue-naive', n)]]; b = [x for x in G[(scen, param, 'queue-proposed', n)]]
    m = 'drainAfterGenMs' if (metric == 'drainMs' and scen == 'S3') else metric  # S3: drenagem medida a partir do último registro gerado
    f = (lambda x: x['procMsTotal'] / x['recordsIn']) if metric == 'procMsPerRecord' else (lambda x: x[m])
    A = np.array([f(x) for x in a if f(x) is not None], float); B = np.array([f(x) for x in b if f(x) is not None], float)
    p = float(mannwhitneyu(A, B, alternative='two-sided').pvalue)
    boots = [np.median(rng.choice(B, len(B))) - np.median(rng.choice(A, len(A))) for _ in range(5000)]
    return dict(scen=scen, param=param, n=n, metric=metric, medV2=float(np.median(A)), medV3=float(np.median(B)),
                diff=float(np.median(B) - np.median(A)), ci=[float(np.percentile(boots, 2.5)), float(np.percentile(boots, 97.5))], p=p)
COMP = []
for scen, param, n in [('S1', '', 300), ('S2', '', 1000), ('S3', '', 300), ('S4', 'resp0.1', 500), ('S4', 'resp0.3', 500), ('S4L', 'L1', 500), ('S5R', '', 1000)]:
    for metric in ['procMsPerRecord', 'latP50', 'requests', 'drainMs']:
        try: COMP.append(compare(metric, scen, param, n))
        except Exception as e: pass
json.dump(dict(summary=S, comparisons=COMP), open(f'{D}/summary.json', 'w'), indent=1)
for c in COMP: print(c)

def figure():
    # Figura 2: (a) latência por execução (p50 e p95) em S1 e S3; (b) drenagem em S2
    plt.rcParams.update({'font.family': 'Liberation Serif', 'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False,
                         'axes.edgecolor': '#555', 'axes.linewidth': 0.6})
    fig, ax = plt.subplots(1, 2, figsize=(6.3, 2.5))
    labels = []; pos = 0; ticks = []
    for scen, n in [('S1', 300), ('S3', 300)]:
        for v, lab, mk, col in [('online', 'V1', 's', '#999'), ('queue-proposed', 'V3', 'o', '#222')]:
            runs = G[(scen, '', v, n)]
            p50 = [x['latP50'] for x in runs]; p95 = [x['latP95'] for x in runs]
            ax[0].scatter([pos - 0.12] * len(p50), p50, marker=mk, s=12, facecolors='none', edgecolors=col, linewidths=0.8)
            ax[0].scatter([pos + 0.12] * len(p95), p95, marker=mk, s=12, color=col)
            ticks.append(pos); labels.append(f'{scen}\n{lab}'); pos += 1
        pos += 0.5
    ax[0].set_yscale('log'); ax[0].set_xticks(ticks, labels)
    ax[0].yaxis.set_major_locator(FixedLocator([0.3, 1, 3, 10, 100, 600])); ax[0].yaxis.set_major_formatter(FixedFormatter(['0,3', '1', '3', '10', '100', '600'])); ax[0].yaxis.set_minor_locator(NullLocator())
    ax[0].set_ylabel('Tempo da operação (ms, log)'); ax[0].set_title('(a) p50 (vazado) e p95 (cheio) por execução', fontsize=9)
    ax[0].yaxis.grid(True, color='#ddd', lw=0.5); ax[0].set_axisbelow(True)
    for v, m, off, col, lab in [('queue-naive', 's', 0.88, '#999', 'V2'), ('queue-proposed', 'o', 1.13, '#222', 'V3')]:
        Ns = [10, 100, 1000]; med = []; lo = []; hi = []
        for n in Ns:
            c = [x['drainMs'] / 1000 for x in G[('S2', '', v, n)]]; med.append(np.median(c)); lo.append(np.median(c) - min(c)); hi.append(max(c) - np.median(c))
        ax[1].errorbar([n * off for n in Ns], med, yerr=[lo, hi], marker=m, ms=5, ls='none', color=col, lw=1.1, capsize=3, label=lab)
    ax[1].set_xscale('log'); ax[1].set_xticks([10, 100, 1000], ['10', '100', '1000'])
    ax[1].yaxis.set_major_formatter(FuncFormatter(lambda y, _: f'{y:.1f}'.replace('.', ',')))
    ax[1].set_xlabel('Registros pendentes'); ax[1].set_ylabel('Drenagem da outbox (s)'); ax[1].set_title('(b) S2: mediana e mín.–máx.', fontsize=9)
    ax[1].legend(frameon=False, fontsize=8, loc='upper left'); ax[1].yaxis.grid(True, color='#ddd', lw=0.5); ax[1].set_axisbelow(True)
    fig.tight_layout(); fig.savefig(f'{D}/fig2_resultados.png', dpi=300)
try: figure()
except (ValueError, KeyError) as e: print('figura não gerada (cenários incompletos):', e)
