'use strict';
// Função de decisão do PEI, compartilhada pelo serviço HTTP (pei_server.js) e pela simulação (pei_sim.js).
// PEI de referência: 2 metas, cada uma com objetivo, estratégia e critério de êxito.
const FIELDS = ['m1_objetivo', 'm1_estrategia', 'm1_criterio', 'm2_objetivo', 'm2_estrategia', 'm2_criterio'];
const metaOf = f => f.slice(0, 2);
const unitOf = (f, granularity) => granularity === 'meta' ? metaOf(f) : f;

function newState(granularity) {
  const units = {};
  for (const f of FIELDS) {
    const u = unitOf(f, granularity);
    units[u] = units[u] || { version: 0, lastOpId: null, lastDevice: null, fields: {}, ts: {}, conflict: null };
    units[u].fields[f] = 'v0'; units[u].ts[f] = -86400;
  }
  return { granularity, units, docTs: -86400, nextConflictId: 1 };
}

// LWW por documento: o salvamento leva o PEI inteiro com o carimbo do relógio do dispositivo
function applyLwwDoc(st, op) {
  if (op.deviceTs > st.docTs) {
    for (const [f, v] of Object.entries(op.snapshot)) st.units[unitOf(f, st.granularity)].fields[f] = v;
    st.docTs = op.deviceTs;
  }
  return 'applied-or-ignored';
}
// LWW por campo
function applyLwwField(st, op) {
  const u = st.units[unitOf(op.field, st.granularity)];
  if (op.deviceTs > u.ts[op.field]) { u.fields[op.field] = op.value; u.ts[op.field] = op.deviceTs; }
  return 'applied-or-ignored';
}
// Proposta: versão por unidade de reconciliação, encadeamento de edições do mesmo dispositivo e conflito explícito.
// op = { opId, device, field, value, baseVersion, prevOpId }
function decideVersion(st, op) {
  const u = st.units[unitOf(op.field, st.granularity)];
  if (u.conflict) {                       // unidade em revisão: a edição é preservada como alternativa
    u.conflict.alternatives.push({ opId: op.opId, device: op.device, field: op.field, value: op.value });
    u.conflict.rev++;
    return { result: 'conflict', conflictId: u.conflict.id };
  }
  const ok = op.prevOpId ? op.prevOpId === u.lastOpId : op.baseVersion === u.version;
  if (ok) {
    u.fields[op.field] = op.value; u.version++; u.lastOpId = op.opId; u.lastDevice = op.device;
    return { result: 'applied', version: u.version };
  }
  u.conflict = { id: st.nextConflictId++, rev: 1, createdBySameDevice: u.lastDevice === op.device,
    current: { ...u.fields }, alternatives: [{ opId: op.opId, device: op.device, field: op.field, value: op.value }] };
  return { result: 'conflict', conflictId: u.conflict.id };
}
// Resolução humana: só é aceita se a revisão considerou a versão atual do conflito (rev)
function resolve(st, unitKey, conflictId, rev, decisions, resolutionId) {
  const u = st.units[unitKey];
  if (!u || !u.conflict || u.conflict.id !== conflictId || u.conflict.rev !== rev) return { result: 'stale' };
  for (const [f, v] of Object.entries(decisions)) u.fields[f] = v;
  u.version++; u.lastOpId = resolutionId; u.lastDevice = 'revisor';
  const closed = u.conflict; u.conflict = null;
  return { result: 'resolved', version: u.version, closed };
}
module.exports = { FIELDS, metaOf, unitOf, newState, applyLwwDoc, applyLwwField, decideVersion, resolve };
