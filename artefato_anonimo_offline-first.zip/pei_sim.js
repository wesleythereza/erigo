'use strict';
// S6: edições concorrentes do PEI em dois dispositivos offline, com defasagem de relógio (simulação, sem rede)
const R = require('./reconcile');
const { mulberry32 } = require('./rng');
const rand = mulberry32(20260915);
const pick = a => a[Math.floor(rand() * a.length)];
function genEdits(dev, skew) {
  const k = 1 + Math.floor(rand() * 3); const out = [];
  for (let i = 0; i < k; i++) { const real = rand() * 3600; out.push({ device: dev, field: pick(R.FIELDS), real, deviceTs: real + skew, value: `${dev}-${i}-${Math.floor(rand() * 1e9)}` }); }
  return out.sort((a, b) => a.real - b.real);
}
const POLICIES = [['lww-doc', 'field'], ['lww-field', 'field'], ['version', 'field'], ['version', 'meta']];
function trial(policy, gran, skew, eds, order) {
  const st = R.newState(gran);
  let opn = 0;
  for (const dev of order) {
    const local = {}; for (const f of R.FIELDS) local[f] = 'v0';
    const lastLocal = {};
    for (const e of eds[dev]) {
      local[e.field] = e.value;
      if (policy === 'lww-doc') R.applyLwwDoc(st, { snapshot: { ...local }, deviceTs: e.deviceTs });
      else if (policy === 'lww-field') R.applyLwwField(st, { field: e.field, value: e.value, deviceTs: e.deviceTs });
      else {
        const uk = R.unitOf(e.field, gran); const opId = `${dev}-${opn++}`;
        R.decideVersion(st, { opId, device: dev, field: e.field, value: e.value, baseVersion: 0, prevOpId: lastLocal[uk] || null });
        lastLocal[uk] = opId;
      }
    }
  }
  const val = f => st.units[R.unitOf(f, gran)].fields[f];
  const preserved = (f, v) => { const c = st.units[R.unitOf(f, gran)].conflict; return !!c && c.alternatives.some(a => a.field === f && a.value === v); };
  const m = { single: 0, singleLost: 0, conc: 0, concOld: 0, concDiscardSilent: 0, concPreserved: 0, metasMixed: 0, metasIncoherent: 0, conflicts: 0 };
  for (const f of R.FIELDS) {
    const lastA = eds.A.filter(e => e.field === f).pop(), lastB = eds.B.filter(e => e.field === f).pop();
    const kept = e => val(f) === e.value || preserved(f, e.value);
    if (lastA && lastB) {
      m.conc++; const [older, newer] = lastA.real < lastB.real ? [lastA, lastB] : [lastB, lastA];
      if (val(f) === older.value && !preserved(f, newer.value)) m.concOld++;
      if (!kept(lastA) || !kept(lastB)) m.concDiscardSilent++; else m.concPreserved++;
    } else if (lastA || lastB) {
      m.single++; if (!kept(lastA || lastB)) m.singleLost++;
    }
  }
  // incoerência semântica: campos diferentes da mesma meta alterados por autores diferentes, aplicados sem revisão
  for (const meta of ['m1', 'm2']) {
    const fs = R.FIELDS.filter(f => R.metaOf(f) === meta);
    const byA = fs.filter(f => eds.A.some(e => e.field === f)), byB = fs.filter(f => eds.B.some(e => e.field === f));
    const onlyA = byA.filter(f => !byB.includes(f)), onlyB = byB.filter(f => !byA.includes(f));
    if (onlyA.length && onlyB.length) {
      m.metasMixed++;
      const applied = f => { const la = eds.A.filter(e => e.field === f).pop() || eds.B.filter(e => e.field === f).pop(); return val(f) === la.value; };
      const reviewed = fs.some(f => st.units[R.unitOf(f, gran)].conflict);
      if (!reviewed && onlyA.some(applied) && onlyB.some(applied)) m.metasIncoherent++;
    }
  }
  m.conflicts = Object.values(st.units).filter(u => u.conflict).length;
  return m;
}
const TR = 10000; const rows = [];
for (const skew of [0, -600, 600]) {
  const S = {}; for (const [p, g] of POLICIES) S[p + '/' + g] = { policy: p, gran: g, skew, trials: TR, trialsLoss: 0, trialsReview: 0, trialsConc: 0 };
  for (let t = 0; t < TR; t++) {
    const eds = { A: genEdits('A', 0), B: genEdits('B', skew) }; const order = rand() < 0.5 ? ['A', 'B'] : ['B', 'A'];
    for (const [p, g] of POLICIES) {   // mesma carga para todas as políticas (pareamento)
      const m = trial(p, g, skew, eds, order); const s = S[p + '/' + g];
      for (const k in m) s[k] = (s[k] || 0) + m[k];
      if (m.singleLost + m.concDiscardSilent > 0) s.trialsLoss++;
      if (m.conflicts > 0) s.trialsReview++;
      if (m.conc > 0) s.trialsConc++;
    }
  }
  rows.push(...Object.values(S));
}
const OUTP = require('./outguard')(process.argv[2], 'node pei_sim.js runs/<RUN_ID>/pei.json'); require('fs').mkdirSync(require('path').dirname(OUTP), { recursive: true });
require('fs').writeFileSync(OUTP, JSON.stringify(rows, null, 1));
const pc = (a, b) => (100 * a / b).toFixed(1);
console.table(rows.map(r => ({ pol: r.policy + '/' + r.gran, skew: r.skew, singleLost: pc(r.singleLost, r.single), concOld: pc(r.concOld, r.conc), discardSilent: pc(r.concDiscardSilent, r.conc), preserved: pc(r.concPreserved, r.conc), incoh: pc(r.metasIncoherent, r.metasMixed), trialsLoss: pc(r.trialsLoss, r.trials), review: pc(r.trialsReview, r.trials), concTr: pc(r.trialsConc, r.trials) })));
