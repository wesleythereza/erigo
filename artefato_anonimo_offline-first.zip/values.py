import sys, os
from outguard import run_dir
D = run_dir('python3 values.py runs/<RUN_ID>')
import json
J = json.load(open(f'{D}/summary.json')); S = J['summary']; C = J['comparisons']
P = json.load(open(f'{D}/pei.json'))
H = json.load(open(f'{D}/pei_http_summary.json'))
R = [json.loads(l) for l in open(f'{D}/raw.jsonl')]
br = lambda x, nd=1: f'{x:.{nd}f}'.replace('.', ',')
def g(key): return S[key]
V = {}
V['TITLE'] = 'Registros pedagógicos sob conectividade intermitente: avaliação de uma arquitetura offline-first para aplicativos educacionais voltados ao TEA'
V['RUNS_ALL'] = len(R); V['RUNS_ALL_PT'] = f'{len(R):,}'.replace(',', '.')
v3 = [r for r in R if r['variant'] == 'queue-proposed']
V['RUNS_V3'] = len(v3); V['RUNS_V3_PT'] = len(v3)
assert sum(r['lost'] for r in v3) == 0 and sum(r['duplicates'] for r in v3) == 0 and all(r['finished'] for r in v3)
V['V3_LOST_TOTAL'] = 0
V['PEI_TRIALS'] = f"{sum(h['trials'] for h in H):,}"; V['PEI_TRIALS_PT'] = V['PEI_TRIALS'].replace(',', '.')
V['ARTIFACT_URL'] = '[URL do repositório anonimizado]'

def mmm(key, k, nd=0, scale=1.0):
    d = g(key)[k]; return f"{br(d['mean']*scale, nd)} [{br(d['min']*scale, nd)}–{br(d['max']*scale, nd)}]"
def med(key, k, nd=1, scale=1/1000):
    d = g(key)[k]; return f"{br(d['median']*scale, nd)} [{br(d['min']*scale, nd)}–{br(d['max']*scale, nd)}]"
# tabela de integridade (valores formatados)
T = {}
def row(key):
    s = g(key)
    return dict(sched=br(s['scheduled']['mean'], 0), started=br(s['started']['mean'], 0), conf=br(s['confirmedServer']['mean'], 0),
                lostSil=br(s['lostSilent']['mean'], 1), lostNot=br(s['lostNotified']['mean'], 1), dup=mmm(key, 'duplicates'),
                drain=('—' if '|online|' in key else (med(key, 'drainAfterGenMs') if key.startswith('S3|') else (med(key, 'drainMs') if s['drainMs'] and s['drainMs']['median'] > 0 else '—'))))
for key in S: T[key] = row(key)
V['T'] = T
# destaques
V['S3_V1_LOST_PCT'] = br(100 * g('S3||online|300')['lost']['mean'] / 300)
V['S3_V1_LOST_MIN'] = int(g('S3||online|300')['lost']['min']); V['S3_V1_LOST_MAX'] = int(g('S3||online|300')['lost']['max'])
V['S4_30_V1_START'] = br(g('S4|resp0.3|online|500')['started']['mean'], 0)
V['S4_30_V1_SNU'] = br(g('S4|resp0.3|online|500')['serverNotUser']['mean'], 0)
V['S5R_V1_SNU'] = br(g('S5R||online|500')['serverNotUser']['mean'], 1)
for key, tag in [('S1||online|300', 'S1_V1'), ('S1||queue-proposed|300', 'S1_V3'), ('S3||online|300', 'S3_V1'), ('S4|resp0.3|online|500', 'S4_V1'), ('S5R||online|500', 'S5R_V1')]:
    V[tag + '_P50'] = br(g(key)['latP50']['median'], 2 if 'V3' in tag else 1); V[tag + '_P95'] = br(g(key)['latP95']['median'], 2 if 'V3' in tag else 0)
V['S1_V1_P50'] = br(g('S1||online|300')['latP50']['median'], 2); V['S1_V1_P95'] = br(g('S1||online|300')['latP95']['median'], 2)
V['S2_V3_1000_DRAIN'] = med('S2||queue-proposed|1000', 'drainMs'); V['S2_V3_1000_REQ'] = br(g('S2||queue-proposed|1000')['requests']['mean'], 0)
V['S2_V3_10_DRAIN'] = med('S2||queue-proposed|10', 'drainMs'); V['S2_V3_100_DRAIN'] = med('S2||queue-proposed|100', 'drainMs')
V['L2_V2_DUP'] = mmm('S4L|L2|queue-naive|500', 'duplicates'); V['L2_V3_DRAIN'] = med('S4L|L2|queue-proposed|500', 'drainMs'); V['L2_V2_DRAIN'] = med('S4L|L2|queue-naive|500', 'drainMs')
V['L1_V2_DUP'] = mmm('S4L|L1|queue-naive|500', 'duplicates')
V['S4_10_V2_DUP'] = mmm('S4|resp0.1|queue-naive|500', 'duplicates'); V['S4_30_V2_DUP'] = mmm('S4|resp0.3|queue-naive|500', 'duplicates')
V['S4_V3_OOO'] = br(g('S4|resp0.3|queue-proposed|500')['outOfOrder']['mean'], 0)
V['S5R_V2_DUP'] = mmm('S5R||queue-naive|1000', 'duplicates')
V['S3_V2_DUP_MAX'] = int(g('S3||queue-naive|300')['duplicates']['max'])
# custo
def comp(scen, param, metric):
    for c in C:
        if c['scen'] == scen and c['param'] == param and c['metric'] == metric: return c
sig = [c for c in C if c['p'] < 0.05]
V['COST_SIG'] = '; '.join(f"{c['scen']}{('/' + c['param']) if c['param'] else ''} {c['metric']}" for c in sig)
pr = [c for c in C if c['metric'] == 'procMsPerRecord']
V['PROC_V2_RANGE'] = f"{br(min(c['medV2'] for c in pr if c['scen'] != 'S1' and c['scen'] != 'S3'), 3)}–{br(max(c['medV2'] for c in pr if c['scen'] not in ('S1', 'S3')), 3)}"
c2 = comp('S2', '', 'procMsPerRecord'); V['S2_PROC_V2'] = br(c2['medV2'], 3); V['S2_PROC_V3'] = br(c2['medV3'], 3); V['S2_PROC_DIFF'] = br(c2['diff'], 3); V['S2_PROC_CI'] = f"{br(c2['ci'][0], 3)} a {br(c2['ci'][1], 3)}"; V['S2_PROC_P'] = f"{c2['p']:.3f}".replace('.', ',')
c4 = comp('S4', 'resp0.1', 'procMsPerRecord'); V['S4_PROC_DIFF'] = br(c4['diff'], 4); V['S4_PROC_P'] = f"{c4['p']:.2f}".replace('.', ',')
lp = [c for c in C if c['metric'] == 'latP50']; V['LAT_DIFF_MAX'] = br(max(abs(c['diff']) for c in lp), 2)
cl = comp('S2', '', 'latP50'); V['S2_LAT_DIFF'] = br(cl['diff'], 2); V['S2_LAT_P'] = f"{cl['p']:.3f}".replace('.', ',')
V['N_COMP'] = len(C); V['N_SIG'] = len(sig)
dr = [c for c in C if c['metric'] in ('drainMs', 'requests')]; V['DRAIN_REQ_SIG'] = sum(1 for c in dr if c['p'] < 0.05)
# S6
def prow(policy, gran, skew):
    r = next(x for x in P if x['policy'] == policy and x['gran'] == gran and x['skew'] == skew)
    pc = lambda a, b: br(100 * a / b) if b else '—'
    return dict(single=pc(r['singleLost'], r['single']), old=pc(r['concOld'], r['conc']), discard=pc(r['concDiscardSilent'], r['conc']),
                pres=pc(r['concPreserved'], r['conc']), incoh=pc(r['metasIncoherent'], r['metasMixed']), review=pc(r['trialsReview'], r['trials']),
                conctr=pc(r['trialsConc'], r['trials']))
V['P6'] = {f'{p}|{g_}|{s}': prow(p, g_, s) for p, g_ in [('lww-doc', 'field'), ('lww-field', 'field'), ('version', 'field'), ('version', 'meta')] for s in [0, -600, 600]}
# S7
def hrow(h):
    pc = lambda a, b: br(100 * a / b) if b else '—'
    return dict(gen=h['generated'], lost=h['lostEdits'], dbl=h['doubleApplied'], gaps=h['versionGaps'], notpres=h['notPreserved'],
                conf1=br(h['round1Conflicts'] / h['trials'], 2), false=h['falseConflicts'], falsetr=pc(h['trialsFalseConflict'], h['trials']),
                stale=f"{h['staleRejected']}/{h['reviewAttempts']}", prop=pc(h['propApplied'], h['propTried']), conv=pc(h['trialsAllConverged'], h['trials']),
                incoh=pc(h['metasIncoherent'], h['metasMixed']) if h['metasMixed'] else '0,0', review=pc(h['trialsReview'], h['trials']), replays=h['replays'])
def hrow2(h):
    r = hrow(h)
    r['viol'] = f"{h['opMissing'] + h['doubleApplied'] + h['versionGaps']}/{h['generated']}"
    r['falsetr_n'] = f"{h['trialsFalseConflict']}/{h['trials']}"
    r['stale_n'] = f"{h['resGenuineStale']}/{h['resolutionIds']}"
    r['resend_n'] = str(h['replayResolved']) if h['idem'] else str(h['resResentAfterApplied'])
    r['prop_n'] = f"{h['propApplied']}/{h['propTried']}"
    r['conv_n'] = f"{h['trialsAllConverged']}/{h['trials']}"
    r['review_n'] = f"{h['trialsReview']}/{h['trials']}"
    r['incoh_n'] = f"{h['metasIncoherent']}/{h['metasMixed']}"
    return r
V['P7'] = {f"{h['idem']}|{h['unit']}|{h['respDrop']}": hrow2(h) for h in H}
json.dump(V, open(f'{D}/values.json', 'w'), ensure_ascii=False, indent=1)
print(json.dumps({k: v for k, v in V.items() if k not in ('T',)}, ensure_ascii=False, indent=1)[:6000])
V['P6_LWWF_OLD'] = V['P6']['lww-field|field|-600']['old']
V['P6_VF_INCOH'] = V['P6']['version|field|0']['incoh']; V['P6_VM_REVIEW'] = V['P6']['version|meta|0']['review']; V['P6_VF_REVIEW'] = V['P6']['version|field|0']['review']
V['P7_REPLAYS'] = V['P7']['1|meta|0.3']['replays']; V['P7_PROP'] = V['P7']['1|meta|0.3']['prop']
V['P7_STALE_META'] = V['P7']['1|meta|0']['stale'].replace('/', ' de ')
V['P7_NOID_FALSE'] = V['P7']['0|meta|0.3']['falsetr'] + '% (meta) e ' + V['P7']['0|field|0.3']['falsetr'] + '% (campo)'
json.dump(V, open(f'{D}/values.json', 'w'), ensure_ascii=False, indent=1)
Hm = next(h for h in H if h['idem'] == 1 and h['unit'] == 'meta' and h['respDrop'] == 0.3)
Hm0 = next(h for h in H if h['idem'] == 1 and h['unit'] == 'meta' and h['respDrop'] == 0)
Nm = next(h for h in H if h['idem'] == 0 and h['unit'] == 'meta' and h['respDrop'] == 0.3)
Nf = next(h for h in H if h['idem'] == 0 and h['unit'] == 'field' and h['respDrop'] == 0.3)
V.update(P7_GEN=f"{Hm['generated']:,}".replace(',', '.'), P7_APP=Hm['opApplied'], P7_PRES=Hm['opPreserved'], P7_EDIT_REPLAYS=Hm['replays'],
         P7_RES_REPLAYS=Hm['replayResolved'], P7_STALE0=f"{Hm0['resGenuineStale']} de {Hm0['resolutionIds']}", P7_STALE3=f"{Hm['resGenuineStale']} de {Hm['resolutionIds']}",
         P7_NOID_FALSE_M=f"{Nm['trialsFalseConflict']}", P7_NOID_FALSE_F=f"{Nf['trialsFalseConflict']}",
         P7_NOID_RESEND_M=Nm['resResentAfterApplied'], P7_NOID_RESEND_F=Nf['resResentAfterApplied'],
         P7_NOID_PROP_M=f"{Nm['propApplied']}/{Nm['propTried']}", P7_NOID_PROP_F=f"{Nf['propApplied']}/{Nf['propTried']}",
         P7_NOID_OPEN=Nm['openAtEnd'] + Nf['openAtEnd'])
json.dump(V, open(f'{D}/values.json', 'w'), ensure_ascii=False, indent=1)
# v4: verificação de ordem por pares, violações separadas, reenvios instrumentados, verificação de reinício
assert all(r.get('orderVerified') for r in R), 'ordem não verificada em alguma execução'
V['ORDER_OK_RUNS'] = sum(1 for r in R if r.get('orderVerified'))
for h in H:
    k = f"{h['idem']}|{h['unit']}|{h['respDrop']}"
    V['P7'][k]['opviol_n'] = f"{h['opViolations']}/{h['generated']:,}".replace(',', '.')
    V['P7'][k]['unitviol_n'] = f"{h['unitViolations']}/{h['units']:,}".replace(',', '.')
    V['P7'][k]['stale_n'] = f"{h['resGenuineStale']}/{h['resolutionIds']}"
    V['P7'][k]['prop_n'] = f"{h['propApplied']}/{h['propTried']}"
V.update(P7_EDIT_RETX=f"{Hm['editRetransmissions']:,}".replace(',', '.'), P7_SRV_OP_REPLAYS=f"{Hm['serverOpReplays']:,}".replace(',', '.'),
         P7_SRV_RES_REPLAYS=Hm['serverResReplays'], P7_EDIT_RECOVERED=Hm['opsRecoveredFromMemo'],
         P7_RES_RECOVERED=Hm['replayResolved'] + Hm['replayStale'], P7_RES_REC_APPLIED=Hm['replayResolved'], P7_RES_REC_STALE=Hm['replayStale'], P7_RES_RETX=Hm['resRetransmissions'])
rt = json.load(open(f'{D}/restart_test.json')) if os.path.exists(f'{D}/restart_test.json') else None
V['RESTART_CHECKS'] = f"{len(rt['checks']) - rt['failed']} de {len(rt['checks'])}" if rt else '—'
V['ENV'] = json.load(open(f'{D}/env.json')) if os.path.exists(f'{D}/env.json') else None
json.dump(V, open(f'{D}/values.json', 'w'), ensure_ascii=False, indent=1)
sig = [c for c in C if c['p'] < 0.05]
assert all(c['metric'] == 'procMsPerRecord' for c in sig), 'há diferença significativa fora do processamento: revisar o texto'
V['COST_SIG_PT'] = ', '.join(c['scen'] + (' com ' + c['param'].replace('resp0.', '') + '0%' if c['param'] else '') for c in sig)
c2 = comp('S2', '', 'procMsPerRecord'); V['S2_PROC_P'] = '< 0,001' if c2['p'] < 0.001 else '= ' + f"{c2['p']:.3f}".replace('.', ',')
json.dump(V, open(f'{D}/values.json', 'w'), ensure_ascii=False, indent=1)
