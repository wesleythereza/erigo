#!/usr/bin/env bash
# Reexecução completa da bancada. Cada execução grava em runs/<RUN_ID>/ e nunca altera results/ (resultados publicados).
set -euo pipefail
cd "$(dirname "$0")"
RUN_ID="${RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)}"
OUT="runs/$RUN_ID"
if [ -e "$OUT" ]; then echo "erro: $OUT já existe; defina outro RUN_ID para não misturar execuções" >&2; exit 1; fi
mkdir -p "$OUT" tmp
REPS="${REPS:-10}"; TRIALS="${TRIALS:-200}"; SCENARIOS="${SCENARIOS:-S5P S4L S1 S2 S3 S4 S5R}"
echo "execução $RUN_ID: REPS=$REPS TRIALS=$TRIALS SCENARIOS=$SCENARIOS" | tee "$OUT/run.log"
node --no-warnings env_info.js > "$OUT/env.json"
node --no-warnings restart_test.js "$OUT/restart_test.json" >> "$OUT/run.log"
for s in $SCENARIOS; do
  REPS="$REPS" node --no-warnings harness.js "$s" "$OUT/raw.jsonl" 2>> "$OUT/run.log"
  echo "concluído $s" >> "$OUT/run.log"
done
TRIALS="$TRIALS" node --no-warnings pei_harness.js "$OUT/pei_http.jsonl" 2>> "$OUT/pei_run.log"
node --no-warnings pei_sim.js "$OUT/pei.json" > "$OUT/pei_sim.log"
python3 analysis.py "$OUT" > "$OUT/analysis.log"
python3 pei_analysis.py "$OUT" > /dev/null
if [ "$SCENARIOS" = "S5P S4L S1 S2 S3 S4 S5R" ] && [ "$REPS" = "10" ] && [ "$TRIALS" = "200" ]; then
  python3 values.py "$OUT" > /dev/null
else
  echo "execução reduzida: values.json (valores do artigo) só é gerado na execução completa" | tee -a "$OUT/run.log"
fi
(cd "$OUT" && sha256sum -- *.json *.jsonl > MANIFEST.sha256)
echo "FIM $RUN_ID" | tee -a "$OUT/run.log"
