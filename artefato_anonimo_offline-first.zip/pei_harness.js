'use strict';
// S7: serviço do PEI sob falhas de rede — edições encadeadas, reenvios, concorrência, resolução e propagação
const { spawn } = require('child_process');
const http = require('http');
const fs = require('fs');
const R = require('./reconcile');
const { mulberry32, hashSeed } = require('./rng');
const sleep = ms => new Promise(r => setTimeout(r, ms));
let portBase = 5000 + Math.floor(Math.random() * 500);
const OUT = require('./outguard')(process.argv[2], 'node pei_harness.js runs/<RUN_ID>/pei_http.jsonl');
const TRIALS = +(process.env.TRIALS || 200);
fs.mkdirSync('tmp', { recursive: true }); fs.mkdirSync(require('path').dirname(OUT), { recursive: true });
const exited = p => (p.exitCode !== null || p.signalCode !== null) ? Promise.resolve() : new Promise(r => p.once('exit', r));

function start(script, argv) { return new Promise(res => { const p = spawn('node', ['--no-warnings', script, ...argv], { stdio: ['ignore', 'pipe', 'inherit'] }); p.stdout.once('data', () => res(p)); }); }
function call(port, path, body, timeout = 1000) {
  return new Promise((resolve, reject) => {
    const data = body ? Buffer.from(JSON.stringify(body)) : null;
    const rq = http.request({ host: '127.0.0.1', port, path, method: body ? 'POST' : 'GET', agent: false,
      headers: data ? { 'content-type': 'application/json', 'content-length': data.length } : {} }, rs => {
      const c = []; rs.on('data', d => c.push(d)); rs.on('end', () => { try { resolve({ status: rs.statusCode, body: JSON.parse(Buffer.concat(c)) }); } catch (e) { reject(e); } });
      rs.on('error', reject);
    });
    rq.setTimeout(timeout, () => rq.destroy(new Error('timeout'))); rq.on('error', reject); rq.end(data || undefined);
  });
}
function admin(port, cfg) { return call(port, '/', cfg).catch(() => null); }

class Device {
  constructor(name, port, rand) { Object.assign(this, { name, port, rand, seq: 0, pending: [], base: {}, chain: {}, replica: {}, generated: [], results: {}, sends: 0 }); }
  async retry(fn) { let b = 50; for (;;) { try { return await fn(); } catch { await sleep(this.rand() * b); b = Math.min(2 * b, 800); } } }
  async pull() {
    const r = await this.retry(() => call(this.port, '/pei/state'));
    this.replica = {}; this.base = {}; this.chain = {};
    for (const [k, u] of Object.entries(r.body.units)) { this.base[k] = u.version; Object.assign(this.replica, u.fields); }
    return r.body;
  }
  edit(field, value) {
    const u = R.unitOf(field, this.gran);
    const op = { opId: `${this.name}-${this.seq++}`, field, value, baseVersion: this.base[u], prevOpId: this.chain[u] || null };
    this.chain[u] = op.opId; this.pending.push(op); this.generated.push(op.opId); this.replica[field] = value;
    return op;
  }
  async sync() {
    while (this.pending.length) {
      const batch = this.pending.slice(0, 1);
      const r = await this.retry(async () => { this.sends++; const x = await call(this.port, '/pei/ops', { device: this.name, ops: batch }); if (x.status !== 200) throw new Error(); return x; });
      for (const res of r.body.results) this.results[res.opId] = res;
      this.pending.splice(0, batch.length);
      await sleep(this.rand() * 30);
    }
  }
}

async function runTrial(cfg, t) {
  const seed = hashSeed(`S7|${cfg.idem}|${cfg.unit}|${cfg.respDrop}|${t}`); const rand = mulberry32(seed);
  if (portBase > 11000) portBase = 5000;
  const sp = portBase++, pp = portBase++, ap = portBase++; const dbf = `tmp/pei-${seed}-${Date.now()}.db`;
  const server = await start('pei_server.js', [`--port=${sp}`, `--db=${dbf}`, `--idem=${cfg.idem}`, `--unit=${cfg.unit}`]);
  const proxy = await start('proxy.js', [`--port=${pp}`, `--target=${sp}`, `--admin=${ap}`, `--seed=${seed}`]);
  await admin(ap, { reqDrop: 0.05, respDrop: cfg.respDrop, delayMin: 0, delayMax: 30 });
  const devs = ['prof', 'terap'].map(n => { const d = new Device(n, pp, mulberry32(hashSeed(n + seed))); d.gran = cfg.unit; return d; });
  for (const d of devs) await d.pull();
  // fase offline: 1 a 4 edições por dispositivo (podem repetir o mesmo campo)
  for (const d of devs) { const k = 1 + Math.floor(rand() * 4); for (let i = 0; i < k; i++) d.edit(R.FIELDS[Math.floor(rand() * R.FIELDS.length)], `${d.name}-${i}-${Math.floor(rand() * 1e6)}`); }
  const round1 = new Set(devs.flatMap(d => d.generated));
  // sincronização concorrente + revisor atuando durante a chegada de novas edições
  let syncing = true; const rev = { attempts: 0, sends: 0, stale: 0, resolved: 0, replayResolved: 0, replayStale: 0, lostResponses: 0 }; let resSeq = 0;
  const reviewer = (async () => {
    for (;;) {
      let s; try { s = (await call(pp, '/pei/state')).body; } catch { await sleep(20); continue; }
      const open = Object.entries(s.units).filter(([, u]) => u.conflict);
      if (!open.length && !syncing) break;
      for (const [unit, u] of open) {
        await sleep(rand() * 40);
        const decisions = {}; for (const a of u.conflict.alternatives) decisions[a.field] = a.value; // decisão: última alternativa por campo
        const body = { resolutionId: `rev-${resSeq++}`, unit, conflictId: u.conflict.id, rev: u.conflict.rev, decisions };
        rev.attempts++;
        for (let tries = 0; tries < 20; tries++) {           // mesma resolução reenviada até obter resposta
          try {
            rev.sends++;
            const r = await call(pp, '/pei/resolve', body);
            if (r.body.replay) { if (r.status === 409) rev.replayStale++; else rev.replayResolved++; }
            else if (r.status === 409) rev.stale++; else rev.resolved++;
            break;
          } catch { rev.lostResponses++; await sleep(20); }
        }
      }
      await sleep(20 + rand() * 40);
    }
  })();
  await Promise.all(devs.map(d => d.sync())); syncing = false; await reviewer;
  // propagação: cada dispositivo atualiza sua réplica e edita uma unidade que passou por conflito
  const auditMid = (await call(sp, '/pei/audit')).body;
  const conflictUnits = [...new Set(auditMid.conflicts.map(c => c.unit))];
  let propTried = 0, propApplied = 0;
  for (const d of devs) {
    await d.pull();
    const unit = conflictUnits.length ? conflictUnits[Math.floor(rand() * conflictUnits.length)] : null;
    const field = unit ? R.FIELDS.find(f => R.unitOf(f, cfg.unit) === unit) : R.FIELDS[0];
    const op = d.edit(field, `${d.name}-prop`); await d.sync(); propTried++;
    if (d.results[op.opId]?.result === 'applied') propApplied++;
  }
  // convergência: réplicas finais iguais ao estado do servidor
  const serverState = (await call(sp, '/pei/state')).body; const truth = {}; for (const u of Object.values(serverState.units)) Object.assign(truth, u.fields);
  let converged = 0; for (const d of devs) { await d.pull(); if (JSON.stringify(Object.entries(d.replica).sort()) === JSON.stringify(Object.entries(truth).sort())) converged++; }
  const a = (await call(sp, '/pei/audit')).body;
  server.kill(); proxy.kill(); await Promise.all([exited(server), exited(proxy)]); for (const f of fs.readdirSync('tmp')) if (f.startsWith(dbf.slice(4))) fs.rmSync('tmp/' + f, { force: true });
  // invariantes
  const allGen = devs.flatMap(d => d.generated);
  const seenOps = new Set(a.ops.map(o => o.opId));
  const lostEdits = allGen.filter(id => !seenOps.has(id)).length;
  const histIds = new Set(a.history.map(x => x.opId));
  const firstResult = {}; for (const o of a.ops) if (!(o.opId in firstResult)) firstResult[o.opId] = o.result;
  const histCount = {}; for (const h of a.history) if (!h.opId.startsWith('res-')) histCount[h.opId] = (histCount[h.opId] || 0) + 1;
  const doubleApplied = Object.values(histCount).filter(c => c > 1).length;
  const byUnit = {}; for (const h of a.history) (byUnit[h.unit] = byUnit[h.unit] || new Set()).add(h.version);
  let versionGaps = 0; for (const [u, vs] of Object.entries(byUnit)) { const arr = [...vs].sort((x, y) => x - y); if (arr.some((v, i) => v !== i + 1) || arr[arr.length - 1] !== serverState.units[u].version) versionGaps++; }
  // edições em conflito que não constam das alternativas preservadas
  const altIds = new Set(a.conflicts.flatMap(c => c.alternatives ? JSON.parse(c.alternatives).map(x => x.opId) : []));
  for (const u of Object.values(serverState.units)) if (u.conflict) for (const x of u.conflict.alternatives) altIds.add(x.opId);
  const openAtEnd = Object.values(serverState.units).filter(u => u.conflict).length;
  const conflictOps = [...new Set(a.ops.filter(o => o.result === 'conflict').map(o => o.opId))];
  const notPreserved = conflictOps.filter(id => !altIds.has(id)).length;
  const falseConflicts = a.conflicts.filter(c => c.sameDevice === 1).length;
  // resoluções a partir da auditoria: obsoletas genuínas × reenvios de resoluções já aplicadas
  const byRes = {}; for (const x of a.resolutions) (byRes[x.resolutionId] = byRes[x.resolutionId] || []).push(x.result);
  let resGenuineStale = 0, resResentAfterApplied = 0, resApplied = 0;
  for (const rows of Object.values(byRes)) {
    if (rows[0] === 'stale') resGenuineStale++;
    if (rows[0] === 'resolved') resApplied++;
    resResentAfterApplied += rows.slice(1).filter((r, i) => r === 'stale' && rows.slice(0, i + 1).includes('resolved')).length;
  }
  // verificador por operação gerada: aplicada (presente no histórico) ou preservada (presente entre alternativas)
  let opApplied = 0, opPreserved = 0, opMissing = 0, appliedNotInHistory = 0;
  for (const id of allGen) {
    const res0 = firstResult[id];
    if (res0 === 'applied') { if (histIds.has(id)) opApplied++; else { appliedNotInHistory++; opMissing++; } }
    else if (res0 === 'conflict') { if (altIds.has(id)) opPreserved++; else opMissing++; }
    else opMissing++;
  }
  // reenvios: cada tentativa é contada no cliente; a memória do servidor registra todo reenvio atendido, inclusive os de resposta perdida
  const editSends = devs.reduce((s, d) => s + d.sends, 0);
  const opsSent = devs.reduce((s, d) => s + Object.keys(d.results).length, 0);
  const serverOpReplays = (a.replays || []).filter(x => x.kind === 'op').length;
  const serverResReplays = (a.replays || []).filter(x => x.kind === 'resolution').length;
  const opsRecoveredFromMemo = devs.reduce((s, d) => s + Object.values(d.results).filter(r => r.replay).length, 0);
  const nUnits = Object.keys(serverState.units).length;
  const replays = devs.reduce((s, d) => s + Object.values(d.results).filter(r => r.replay).length, 0);
  // incoerência semântica (rodada 1): campos distintos da mesma meta alterados por autores distintos sem nenhum conflito na meta
  let metasMixed = 0, metasIncoherent = 0;
  for (const meta of ['m1', 'm2']) {
    const h = a.history.filter(x => round1.has(x.opId) && R.metaOf(x.field) === meta);
    const fieldsBy = dev => new Set(h.filter(x => x.device === dev).map(x => x.field));
    const P = fieldsBy('prof'), T = fieldsBy('terap');
    const onlyP = [...P].filter(f => !T.has(f)), onlyT = [...T].filter(f => !P.has(f));
    if (onlyP.length && onlyT.length) { metasMixed++; if (!a.conflicts.some(c => R.FIELDS.some(f => R.metaOf(f) === meta && R.unitOf(f, cfg.unit) === c.unit))) metasIncoherent++; }
  }
  return { ...cfg, trial: t, seed, generated: allGen.length, lostEdits, doubleApplied, versionGaps, notPreserved, conflicts: a.conflicts.length, falseConflicts,
    editSends, editRetransmissions: editSends - opsSent, serverOpReplays, opsRecoveredFromMemo, resSends: rev.sends, resRetransmissions: rev.sends - rev.attempts, serverResReplays,
    opViolations: opMissing + doubleApplied, unitViolations: versionGaps, units: nUnits,
    replays, reviewAttempts: rev.attempts, staleRejected: rev.stale, resolved: rev.resolved, replayResolved: rev.replayResolved, replayStale: rev.replayStale, resolveLostResponses: rev.lostResponses, resGenuineStale, resResentAfterApplied, resApplied, resolutionIds: Object.keys(byRes).length, opApplied, opPreserved, opMissing, appliedNotInHistory, propTried, propApplied, devicesConverged: converged, devices: devs.length,
    metasMixed, metasIncoherent, openAtEnd, round1Conflicts: a.conflicts.filter(c => auditMid.conflicts.some(m => m.id === c.id)).length };
}
if (require.main === module) (async () => {
  if (fs.existsSync(OUT) && fs.statSync(OUT).size > 0) { console.error(`${OUT} já existe; use um arquivo novo para não misturar execuções`); process.exit(1); }
  for (const idem of [1, 0]) for (const unit of ['field', 'meta']) for (const respDrop of [0, 0.3]) {
    const cfg = { idem, unit, respDrop };
    for (let t = 0; t < TRIALS; t++) { const r = await runTrial(cfg, t); fs.appendFileSync(OUT, JSON.stringify(r) + '\n'); }
    console.error('done', JSON.stringify(cfg));
  }
})();
