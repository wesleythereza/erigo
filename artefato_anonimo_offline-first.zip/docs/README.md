# Documentos de projeto de origem

Estes diagramas descrevem o projeto do sistema do qual a arquitetura avaliada no artigo foi derivada. Eles são material de rastreabilidade: mostram de onde vêm as decisões, **não** descrevem o que foi implementado e medido.

- `src/` — fontes em Mermaid (editáveis).
- `png/` — imagens geradas a partir de `src/` (`mmdc -i src/<arquivo>.mmd -o png/<arquivo>.png -b white`).
- `original/` — capturas dos diagramas do projeto de origem, das quais as fontes foram transcritas.

## O que foi implementado e avaliado

O protótipo deste artefato cobre apenas o núcleo de sincronização (`client.js`, `server.js`, `pei_server.js`, `reconcile.js`). A tabela indica, para cada diagrama, o que pertence ao projeto e o que entrou na avaliação.

| Diagrama | Conteúdo | Situação no artefato |
|---|---|---|
| `01_contexto` | Atores e sistemas externos | Projeto. Nenhum sistema externo foi implementado. |
| `02_conteineres` | App React Native, BFF NestJS, PostgreSQL, storage, notificações, observabilidade | Projeto. A bancada usa cliente e servidor de referência em Node.js com SQLite. |
| `03_componentes_app` | Telas, ViewModels, serviços e dados locais | Projeto. O cliente da bancada implementa apenas outbox, agente de sincronização e, no PEI, réplica em memória. |
| `04_componentes_backend` | Controladores, serviços e repositórios | Projeto. O servidor de referência expõe apenas `/sync` (eventos) e `/pei/*`. |
| `05_fluxo_sincronizacao` | Outbox, inbox, resolução de conflitos, recuo e observabilidade | Parcialmente avaliado: gravação local antes do envio, envio em lote, recuo exponencial com _jitter_, retomada após reinício e propagação por leitura do estado. |
| `06_modelo_dados` | Modelo de dados completo | Parcialmente avaliado: registros de atividade com UUID e sequência por dispositivo, filas de eventos e PEI. |
| `07_sequencia_envio` | Conclusão de atividade até a confirmação do servidor | Corresponde ao fluxo avaliado nos cenários S1–S5. |
| `08_sequencia_feed` | Recepção do feed e resolução de conflitos | Ver a divergência 1 abaixo. |
| `09_implantacao` | Implantação prevista em contêineres | Projeto. Não avaliado. |

## Divergências entre o projeto de origem e a proposta avaliada

1. **Resolução de conflitos.** Em `08_sequencia_feed`, o componente *Conflict Resolver* faz merge determinístico (LWW ou regra de domínio). A proposta avaliada no artigo adota, para o PEI, versão por meta, identificadores de operação e conflito explícito, sem descarte silencioso. Os cenários S6 e S7 mostram que as variantes de LWW descartam edições concorrentes sem aviso, inclusive com relógios corretos. **Vale o que está no artigo**; o diagrama registra o projeto anterior.
2. **Campos da meta.** No artigo, cada meta do PEI tem objetivo, estratégia e critério de êxito — um modelo de referência com três campos interdependentes, usado para definir a unidade de reconciliação. No modelo de dados, `GOAL` tem `title`, `description`, `domain` e `achieved`. A correspondência é conceitual: o que importa para a proposta é que a meta agrupa campos interdependentes, e que `ACTIVITYINSTANCE` referencia `goal_id`.
3. **Registros de atividade.** O artigo trata cada registro como evento imutável, corrigido por um novo evento. No modelo de dados, `PROGRESSRECORD` é uma linha por instância de atividade; a política de correção por evento não está representada.

## Nota de privacidade

A tabela `STUDENT` do projeto de origem inclui `diagnosis`. Trata-se de dado pessoal sensível de criança. O artigo propõe cifragem do banco local e minimização de dados, medidas não avaliadas, e não usa esse campo em nenhum experimento. Antes de qualquer uso real, o campo deve ser justificado, restringido ou removido, observados os artigos 11, 14 e 46 da LGPD.
