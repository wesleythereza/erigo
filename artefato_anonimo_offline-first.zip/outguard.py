# Proteção dos resultados publicados: exige diretório explícito e recusa results/
import os, sys
def run_dir(usage):
    if len(sys.argv) < 2:
        sys.exit(f'uso: {usage}\n(o diretório da execução é obrigatório; use runs/<RUN_ID>)')
    d = sys.argv[1]
    pub = os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results'))
    real = os.path.realpath(d)
    if real == pub or real.startswith(pub + os.sep):
        sys.exit(f'recusado: {d} é results/, que guarda os resultados publicados')
    return d
