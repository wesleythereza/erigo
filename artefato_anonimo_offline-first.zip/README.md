# Artefato — núcleo offline-first para registros pedagógicos e PEI

## Ambiente
- **Suportado:** Linux (Docker ou nativo) com Node.js 22.22 (`node:sqlite`, SQLite 3.51) e Python 3 com numpy, scipy e matplotlib.
- **Ambiente dos resultados publicados:** está em `results/env.json`. Trata-se de uma VM KVM com 2 vCPUs Intel Xeon de 2,1 GHz, 7,8 GiB de RAM e disco virtual ext4, sob Ubuntu 24.04 (Linux 6.18), com Node.js 22.22.2, SQLite 3.51.2 e Python 3.11.
- **Outros sistemas:** os executores aguardam o término dos processos antes de apagar seus bancos, o que evita o bloqueio de arquivos observado no Windows. Mesmo assim, Windows e macOS não foram usados para gerar os resultados publicados. Tempos e p-valores dependem do ambiente e não devem ser comparados entre máquinas diferentes.

## Resultados publicados × reexecuções
- `results/` contém a execução usada no artigo (`RUN_ID=v4-publicado`), com `MANIFEST.sha256` (confira com `cd results && sha256sum -c MANIFEST.sha256`).
- **Proteção nas chamadas diretas:** `harness.js`, `pei_harness.js`, `pei_sim.js`, `analysis.py`, `pei_analysis.py` e `values.py` exigem saída ou diretório explícito e recusam qualquer caminho dentro de `results/` (`outguard.js` e `outguard.py`). Exemplo: `node harness.js S1 runs/teste/raw.jsonl`, e depois `python3 analysis.py runs/teste`.
- `./runall.sh` grava em `runs/<RUN_ID>/`. O roteiro recusa um `RUN_ID` já existente e interrompe a execução em qualquer falha (`set -euo pipefail`).
- `pei_harness.js` recusa um arquivo de saída que já exista.

## Reexecução
```
docker build -t bancada .
docker run --rm -v "$PWD/runs:/bancada/runs" bancada          # execução completa (~3 h em 2 vCPUs)
# ou, sem Docker:
./runall.sh                                                    # RUN_ID=data/hora UTC
RUN_ID=teste REPS=1 TRIALS=5 SCENARIOS="S5P" ./runall.sh       # execução reduzida (sem values.json)
node restart_test.js                                           # só a verificação de reinício dos servidores
```
`runall.sh` executa, em ordem:
1. registro do ambiente (`env.json`);
2. verificação de reinício (`restart_test.json`);
3. cenários S1–S5 (`raw.jsonl`);
4. S7 (`pei_http.jsonl`);
5. S6 (`pei.json`);
6. análises (`summary.json`, `pei_http_summary.json`);
7. `values.py` (`values.json`, com os valores das tabelas);
8. manifesto (`MANIFEST.sha256`).

## Componentes
- **`client.js`:** cliente de referência. Opera em `online` (V1) ou `queue` (outbox persistente, V2/V3), com pontos de encerramento P1–P3. O cliente grava o evento direto na outbox e o remove após a confirmação. Não há interface, casos de uso nem repositório local completo.
- **`server.js`:** sincronização de eventos, em `--mode=dedup` (V3) ou `naive` (V2). `/pairs` devolve os pares (dispositivo, sequência) na ordem de reconstrução.
- **`proxy.js`:** injeção de falhas com semente.
- **`harness.js`:** cenários S1–S5. A contagem é feita por estágio, e a ordem é verificada explicitamente: os pares esperados, na ordem de geração, são comparados com os recuperados (`orderVerified`).
- **`reconcile.js`:** função de decisão do PEI e políticas LWW.
- **`pei_sim.js`:** S6.
- **`pei_server.js`:** serviço do PEI.
  - Carrega o estado persistido ao iniciar e só cria estado inicial em banco novo.
  - Recusa um banco criado com outra unidade de reconciliação.
  - Registra cada reenvio atendido pela memória (tabela `replays`).
- **`pei_harness.js`:** S7. O revisor é um agente automatizado que escolhe, por campo, a última alternativa recebida e reenvia a mesma resolução até obter resposta.
  - **Reenvios:** `editSends` e `editRetransmissions` contam cada tentativa no cliente. `serverOpReplays` e `serverResReplays` contam os reenvios atendidos pelo servidor, inclusive os de resposta perdida. `opsRecoveredFromMemo` conta as edições cuja resposta final veio da memória.
  - **Violações:** `opViolations` é contado por edição; `unitViolations` (lacunas de versão) é contado por unidade.
- **`restart_test.js`:** encerra os servidores com SIGKILL, reinicia sobre o mesmo banco e confere estado, versões, conflitos, resoluções e reenvios.
- **`env_info.js`, `analysis.py`, `pei_analysis.py`, `values.py`:** registro do ambiente, agregação por execução, testes de Mann-Whitney com IC bootstrap e valores das tabelas. Os scripts Python recebem o diretório da execução como argumento.

## Documentos de projeto
- `docs/` traz os diagramas do projeto de origem (contexto, contêineres, componentes, modelo de dados, fluxo de sincronização, sequências e implantação), com as fontes em Mermaid, e o `docs/README.md` explica o que foi implementado e avaliado e as divergências em relação à proposta do artigo.

## Limites conhecidos
- Os encerramentos de S5R e S5P atingem apenas o cliente; em S1–S5 e S7, servidor e proxy não são reiniciados. Os servidores só são reiniciados na verificação funcional, não sob carga.
- Encerrar processos não equivale a falta de energia nem a falha de armazenamento.
- `results_v3/` guarda os resultados da versão anterior do artigo, gerados antes da verificação explícita de ordem e da contagem de todas as tentativas de reenvio. Eles ficam no artefato apenas para rastreabilidade.
