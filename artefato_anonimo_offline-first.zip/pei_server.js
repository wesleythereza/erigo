'use strict';
// Serviço HTTP de reconciliação do PEI (protótipo): SQLite + função de decisão de reconcile.js
const http = require('http');
const { DatabaseSync } = require('node:sqlite');
const R = require('./reconcile');
const args = Object.fromEntries(process.argv.slice(2).map(a => a.replace(/^--/, '').split('=')));
const IDEM = args.idem !== '0';              // memória de operações por opId
const GRAN = args.unit || 'field';
const db = new DatabaseSync(args.db);
db.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;');
db.exec(`CREATE TABLE IF NOT EXISTS state(k INTEGER PRIMARY KEY, json TEXT);
  CREATE TABLE IF NOT EXISTS ops(opId TEXT, device TEXT, unit TEXT, field TEXT, value TEXT, result TEXT, conflictId INTEGER, evaluatedAt INTEGER);
  CREATE TABLE IF NOT EXISTS history(unit TEXT, version INTEGER, opId TEXT, field TEXT, value TEXT, device TEXT);
  CREATE TABLE IF NOT EXISTS conflicts(id INTEGER, unit TEXT, sameDevice INTEGER, opened INTEGER, closed INTEGER, alternatives TEXT);
  CREATE TABLE IF NOT EXISTS resolutions(resolutionId TEXT, unit TEXT, conflictId INTEGER, rev INTEGER, result TEXT);
  CREATE TABLE IF NOT EXISTS replays(kind TEXT, id TEXT, servedAt INTEGER);`);
// recuperação: carrega o estado persistido; um estado inicial só é criado em banco novo
const persisted = db.prepare('SELECT json FROM state WHERE k=1').get();
let st = persisted ? JSON.parse(persisted.json) : R.newState(GRAN);
if (st.granularity !== GRAN) { console.error(`banco criado com unidade ${st.granularity}, servidor iniciado com ${GRAN}`); process.exit(2); }
const save = () => db.prepare('INSERT OR REPLACE INTO state(k,json) VALUES(1,?)').run(JSON.stringify(st));
if (!persisted) save();
const insReplay = db.prepare('INSERT INTO replays VALUES(?,?,?)');
const memo = db.prepare('SELECT result, conflictId FROM ops WHERE opId=? ORDER BY rowid LIMIT 1');
const insOp = db.prepare('INSERT INTO ops VALUES(?,?,?,?,?,?,?,?)');
const insHist = db.prepare('INSERT INTO history VALUES(?,?,?,?,?,?)');
const body = req => new Promise(r => { const c = []; req.on('data', d => c.push(d)); req.on('end', () => r(c.length ? JSON.parse(Buffer.concat(c)) : null)); });
const send = (res, code, obj) => { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(obj)); };
http.createServer(async (req, res) => {
  const b = await body(req);
  if (req.url === '/pei/ops') {
    // cada requisição é processada integralmente em uma transação (leitura, decisão e escrita atômicas)
    const out = [];
    db.exec('BEGIN IMMEDIATE');
    for (const op of b.ops) {
      const unit = R.unitOf(op.field, GRAN);
      const prev = IDEM ? memo.get(op.opId) : null;
      if (prev) { insReplay.run('op', op.opId, Date.now()); out.push({ opId: op.opId, result: prev.result, conflictId: prev.conflictId, replay: true }); continue; }
      const hadConflict = !!st.units[unit].conflict;
      const r = R.decideVersion(st, { ...op, device: b.device });
      insOp.run(op.opId, b.device, unit, op.field, op.value, r.result, r.conflictId ?? null, Date.now());
      if (r.result === 'applied') insHist.run(unit, r.version, op.opId, op.field, op.value, b.device);
      if (r.result === 'conflict' && !hadConflict) db.prepare('INSERT INTO conflicts VALUES(?,?,?,?,NULL,NULL)').run(r.conflictId, unit, st.units[unit].conflict.createdBySameDevice ? 1 : 0, Date.now());
      out.push({ opId: op.opId, ...r });
    }
    save(); db.exec('COMMIT');
    return send(res, 200, { results: out });
  }
  if (req.url === '/pei/state') return send(res, 200, { units: Object.fromEntries(Object.entries(st.units).map(([k, u]) => [k, { version: u.version, lastOpId: u.lastOpId, fields: u.fields, conflict: u.conflict ? { id: u.conflict.id, rev: u.conflict.rev, alternatives: u.conflict.alternatives, current: u.conflict.current } : null }])) });
  if (req.url === '/pei/resolve') {
    // resolução idempotente: o reenvio do mesmo resolutionId devolve o resultado já registrado
    if (IDEM) {
      const prev = db.prepare('SELECT result FROM resolutions WHERE resolutionId=? ORDER BY rowid LIMIT 1').get(b.resolutionId);
      if (prev) { insReplay.run('resolution', b.resolutionId, Date.now()); return send(res, prev.result === 'resolved' ? 200 : 409, { result: prev.result, replay: true }); }
    }
    db.exec('BEGIN IMMEDIATE');
    const r = R.resolve(st, b.unit, b.conflictId, b.rev, b.decisions, `res-${b.unit}-${b.conflictId}`);
    db.prepare('INSERT INTO resolutions VALUES(?,?,?,?,?)').run(b.resolutionId, b.unit, b.conflictId, b.rev, r.result);
    if (r.result === 'resolved') {
      for (const [f, v] of Object.entries(b.decisions)) insHist.run(b.unit, r.version, `res-${b.unit}-${b.conflictId}`, f, v, 'revisor');
      db.prepare('UPDATE conflicts SET closed=?, alternatives=? WHERE id=?').run(Date.now(), JSON.stringify(r.closed.alternatives), b.conflictId);
    }
    save(); db.exec('COMMIT');
    return send(res, r.result === 'resolved' ? 200 : 409, { result: r.result });
  }
  if (req.url === '/pei/audit') {
    return send(res, 200, { ops: db.prepare('SELECT * FROM ops').all(), history: db.prepare('SELECT * FROM history').all(),
      conflicts: db.prepare('SELECT * FROM conflicts').all(), resolutions: db.prepare('SELECT * FROM resolutions').all(), replays: db.prepare('SELECT * FROM replays').all() });
  }
  send(res, 404, {});
}).listen(+args.port, () => console.log('ready'));
