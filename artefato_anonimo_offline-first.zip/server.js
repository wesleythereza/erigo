'use strict';
const http = require('http');
const { DatabaseSync } = require('node:sqlite');
const args = Object.fromEntries(process.argv.slice(2).map(a => a.replace(/^--/, '').split('=')));
const mode = args.mode || 'dedup'; // dedup | naive
const db = new DatabaseSync(args.db);
db.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;');
db.exec(`CREATE TABLE IF NOT EXISTS events(
  rid INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT ${mode === 'dedup' ? 'UNIQUE' : ''},
  device TEXT, seq INTEGER, type TEXT, payload TEXT, client_ts INTEGER, recv_ts INTEGER)`);
const ins = db.prepare(`INSERT ${mode === 'dedup' ? 'OR IGNORE' : ''} INTO events(id,device,seq,type,payload,client_ts,recv_ts) VALUES(?,?,?,?,?,?,?)`);
let maxSeq = {}; let outOfOrder = 0; let requests = 0; let bytesIn = 0; const procMs = []; let recordsIn = 0;
function body(req) { return new Promise(r => { const c = []; req.on('data', d => c.push(d)); req.on('end', () => r(Buffer.concat(c))); }); }
http.createServer(async (req, res) => {
  const buf = await body(req);
  if (req.url === '/sync' && req.method === 'POST') {
    requests++; bytesIn += buf.length;
    const { device, events } = JSON.parse(buf);
    const acked = []; const t0 = process.hrtime.bigint(); recordsIn += events.length;
    db.exec('BEGIN');
    try {
      for (const e of events) {
        const r = ins.run(e.id, device, e.seq, e.type, JSON.stringify(e.payload), e.ts, Date.now());
        if (r.changes > 0) {
          if (e.seq < (maxSeq[device] ?? -1)) outOfOrder++;
          maxSeq[device] = Math.max(maxSeq[device] ?? -1, e.seq);
        }
        acked.push(e.id);
      }
      db.exec('COMMIT');
      procMs.push(Number(process.hrtime.bigint() - t0) / 1e6);
    } catch (err) { db.exec('ROLLBACK'); res.writeHead(500); return res.end(); }
    res.writeHead(200, { 'content-type': 'application/json' });
    return res.end(JSON.stringify({ acked }));
  }
  if (req.url === '/stats') {
    const rows = db.prepare('SELECT COUNT(*) n, COUNT(DISTINCT id) d FROM events').get();
    const seqs = db.prepare('SELECT seq FROM events GROUP BY id ORDER BY seq').all().map(x => x.seq);
    res.writeHead(200, { 'content-type': 'application/json' });
    return res.end(JSON.stringify({ rows: rows.n, distinct: rows.d, outOfOrder, requests, bytesIn, seqs, procMsTotal: procMs.reduce((a, b) => a + b, 0), procReq: procMs.length, recordsIn }));
  }
  if (req.url === '/pairs') {
    // pares (dispositivo, sequência) recuperados, na ordem usada pelo servidor para reconstrução
    const pairs = db.prepare('SELECT device, seq, id FROM events GROUP BY id ORDER BY device, seq, MIN(rid)').all();
    res.writeHead(200); return res.end(JSON.stringify(pairs));
  }
  if (req.url === '/ids') {
    const ids = db.prepare('SELECT DISTINCT id FROM events').all().map(x => x.id);
    res.writeHead(200); return res.end(JSON.stringify(ids));
  }
  res.writeHead(404); res.end();
}).listen(+args.port, () => console.log('ready'));
