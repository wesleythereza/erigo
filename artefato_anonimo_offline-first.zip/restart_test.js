'use strict';
// Verificação de reinício dos servidores: encerra com SIGKILL e reinicia sobre o mesmo banco.
// Confere estado, versões, conflitos, resoluções e reenvios (serviço do PEI) e ausência de duplicatas (eventos).
const { spawn } = require('child_process');
const http = require('http');
const fs = require('fs');
const path = require('path');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const exited = p => (p.exitCode !== null || p.signalCode !== null) ? Promise.resolve() : new Promise(r => p.once('exit', r));
const start = (script, argv) => new Promise((res, rej) => {
  const p = spawn('node', ['--no-warnings', script, ...argv], { stdio: ['ignore', 'pipe', 'inherit'] });
  p.stdout.once('data', () => res(p)); p.once('exit', c => rej(new Error(`${script} saiu com ${c}`)));
});
const call = (port, p, body) => new Promise((res, rej) => {
  const data = body ? Buffer.from(JSON.stringify(body)) : null;
  const rq = http.request({ host: '127.0.0.1', port, path: p, method: body ? 'POST' : 'GET', agent: false,
    headers: data ? { 'content-type': 'application/json', 'content-length': data.length } : {} }, rs => {
    const c = []; rs.on('data', d => c.push(d)); rs.on('end', () => { try { res({ status: rs.statusCode, body: JSON.parse(Buffer.concat(c)) }); } catch (e) { res({ status: rs.statusCode, body: null }); } });
  }); rq.on('error', rej); rq.end(data || undefined);
});
const checks = []; const check = (name, ok, detail) => { checks.push({ name, ok: !!ok, detail }); console.log(`${ok ? 'OK  ' : 'FAIL'} ${name}${ok ? '' : ' — ' + JSON.stringify(detail)}`); };
const kill9 = async p => { p.kill('SIGKILL'); await exited(p); };

async function peiTest(unit, port) {
  fs.mkdirSync('tmp', { recursive: true });
  const db = path.join('tmp', `restart-pei-${unit}-${process.pid}.db`);
  const args = [`--port=${port}`, `--db=${db}`, '--idem=1', `--unit=${unit}`];
  let s = await start('pei_server.js', args);
  const f1 = 'm1_objetivo', f2 = unit === 'meta' ? 'm1_estrategia' : 'm1_objetivo';
  const u = unit === 'meta' ? 'm1' : 'm1_objetivo';
  // 1) edição aplicada (versão 1); 2) edição concorrente de outro dispositivo sobre a versão 0 (conflito)
  const e1 = { device: 'prof', ops: [{ opId: 'prof-0', field: f1, value: 'A', baseVersion: 0, prevOpId: null }] };
  const e2 = { device: 'terap', ops: [{ opId: 'terap-0', field: f2, value: 'B', baseVersion: 0, prevOpId: null }] };
  const r1 = await call(port, '/pei/ops', e1); check(`[${unit}] edição aplicada antes do reinício`, r1.body.results[0].result === 'applied', r1.body);
  const r2 = await call(port, '/pei/ops', e2); check(`[${unit}] edição concorrente vira conflito`, r2.body.results[0].result === 'conflict', r2.body);
  const before = (await call(port, '/pei/state')).body;
  await kill9(s); s = await start('pei_server.js', args);
  const after = (await call(port, '/pei/state')).body;
  check(`[${unit}] estado, versão e conflito recuperados após SIGKILL`, JSON.stringify(before) === JSON.stringify(after), { before: before.units[u], after: after.units[u] });
  const rr = await call(port, '/pei/ops', e1);
  const afterReplay = (await call(port, '/pei/state')).body;
  check(`[${unit}] reenvio da edição aplicada devolve o resultado memorizado sem alterar o estado`, rr.body.results[0].replay && rr.body.results[0].result === 'applied' && JSON.stringify(afterReplay) === JSON.stringify(after), rr.body);
  const c = after.units[u].conflict;
  const res = { resolutionId: 'rev-0', unit: u, conflictId: c.id, rev: c.rev, decisions: { [f1]: 'A', [f2]: 'B' } };
  const q1 = await call(port, '/pei/resolve', res); check(`[${unit}] resolução aplicada`, q1.status === 200 && q1.body.result === 'resolved', q1.body);
  const beforeRes = (await call(port, '/pei/state')).body;
  await kill9(s); s = await start('pei_server.js', args);
  const afterRes = (await call(port, '/pei/state')).body;
  check(`[${unit}] resolução e nova versão recuperadas após SIGKILL`, JSON.stringify(beforeRes) === JSON.stringify(afterRes) && afterRes.units[u].conflict === null, afterRes.units[u]);
  const q2 = await call(port, '/pei/resolve', res);
  check(`[${unit}] reenvio da resolução após reinício devolve o resultado memorizado`, q2.status === 200 && q2.body.replay === true, q2.body);
  const e3 = { device: 'prof', ops: [{ opId: 'prof-1', field: f1, value: 'C', baseVersion: afterRes.units[u].version, prevOpId: null }] };
  const r3 = await call(port, '/pei/ops', e3);
  check(`[${unit}] nova edição sobre a versão recuperada é aplicada`, r3.body.results[0].result === 'applied' && r3.body.results[0].version === afterRes.units[u].version + 1, r3.body);
  const audit = (await call(port, '/pei/audit')).body;
  check(`[${unit}] histórico sem aplicação duplicada`, audit.history.filter(h => h.opId === 'prof-0').length === 1, audit.history);
  await kill9(s);
  // unidade incompatível com o banco existente é recusada
  let refused = false; try { const x = await start('pei_server.js', [`--port=${port}`, `--db=${db}`, '--idem=1', `--unit=${unit === 'meta' ? 'field' : 'meta'}`]); await kill9(x); } catch { refused = true; }
  check(`[${unit}] servidor recusa banco criado com outra unidade`, refused);
  for (const f of fs.readdirSync('tmp')) if (f.startsWith(path.basename(db))) fs.rmSync(path.join('tmp', f), { force: true });
}

async function eventsTest(port) {
  const db = path.join('tmp', `restart-events-${process.pid}.db`);
  const args = [`--port=${port}`, `--db=${db}`, '--mode=dedup'];
  let s = await start('server.js', args);
  const events = [0, 1, 2].map(i => ({ id: `00000000-0000-4000-8000-00000000000${i}`, seq: i, type: 't', ts: 0, payload: {} }));
  await call(port, '/sync', { device: 'tablet-01', events });
  await kill9(s); s = await start('server.js', args);
  await call(port, '/sync', { device: 'tablet-01', events });           // reenvio do lote após reinício
  const st = (await call(port, '/stats')).body; const pairs = (await call(port, '/pairs')).body;
  check('[eventos] reenvio após SIGKILL do servidor não duplica registros', st.rows === 3 && st.distinct === 3, st);
  check('[eventos] pares (dispositivo, sequência) recuperados na ordem', pairs.map(p => p.seq).join() === '0,1,2', pairs);
  await kill9(s);
  for (const f of fs.readdirSync('tmp')) if (f.startsWith(path.basename(db))) fs.rmSync(path.join('tmp', f), { force: true });
}

(async () => {
  const port = 31000 + Math.floor(Math.random() * 500);
  await peiTest('meta', port); await sleep(100); await peiTest('field', port + 1); await sleep(100); await eventsTest(port + 2);
  const failed = checks.filter(c => !c.ok).length;
  console.log(`${checks.length - failed}/${checks.length} verificações aprovadas`);
  if (process.argv[2]) fs.writeFileSync(process.argv[2], JSON.stringify({ checks, failed }, null, 1));
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
