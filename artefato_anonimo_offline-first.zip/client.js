'use strict';
// Cliente de referência: online-only (sem persistência local) ou offline-first (outbox em SQLite)
const http = require('http');
const fs = require('fs');
const crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');
const { mulberry32 } = require('./rng');
const args = Object.fromEntries(process.argv.slice(2).map(a => a.replace(/^--/, '').split('=')));
const variant = args.variant;            // online | queue
const N = +(args.n || 0), rate = +(args.rate || 0);
const batch = +(args.batch || 50), parallel = +(args.parallel || 1);
const device = args.device || 'tablet-01';
const [host, port] = args.server.split(':');
const TIMEOUT = +(args.timeout || 2000);
const gtFile = args.gt;                  // instrumentação: registro dos eventos gerados (verdade de referência)
const rand = mulberry32(+(args.seed || 1));
const crashAt = args.crashAt || null, crashK = +(args.crashK || 0); let crashCount = 0;
// encerramento controlado: o próprio cliente recebe SIGKILL no k-ésimo ponto do fluxo indicado
function maybeCrash(point) { if (crashAt === point && ++crashCount === crashK) { emit({ type: 'crash', point }); process.kill(process.pid, 'SIGKILL'); } }
const emit = o => process.stdout.write(JSON.stringify({ ...o, t: Date.now() }) + '\n');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const hr = () => Number(process.hrtime.bigint()) / 1e6;

function post(path, obj, timeout = TIMEOUT) {
  return new Promise((resolve, reject) => {
    const data = Buffer.from(JSON.stringify(obj));
    const rq = http.request({ host, port: +port, path, method: 'POST', agent: false,
      headers: { 'content-type': 'application/json', 'content-length': data.length } }, rs => {
      const c = []; rs.on('data', d => c.push(d));
      rs.on('end', () => rs.statusCode === 200 ? resolve(JSON.parse(Buffer.concat(c))) : reject(new Error('http ' + rs.statusCode)));
      rs.on('error', reject);
    });
    rq.setTimeout(timeout, () => rq.destroy(new Error('timeout')));
    rq.on('error', reject); rq.end(data);
  });
}
function makeEvent(seq) {
  return { id: crypto.randomUUID(), seq, type: 'atividade_concluida', ts: Date.now(),
    payload: { aluno: 'A' + (seq % 7), atividade: 'pareamento-' + (seq % 12), acertos: seq % 5, tentativas: 1 + (seq % 3), latenciaMs: 800 + (seq % 900) } };
}

async function runOnline() {
  let seq = +(args.seqStart || 0);
  for (let i = 0; i < N; i++, seq++) {
    const e = makeEvent(seq);
    fs.appendFileSync(gtFile, `${e.id},${e.seq}\n`);
    const t0 = hr(); let ok = false;
    maybeCrash('P1');
    for (let a = 0; a < 3 && !ok; a++) {   // até 3 tentativas em memória
      try { await post('/sync', { device, events: [e] }); ok = true; } catch { await sleep(200); }
    }
    if (ok) maybeCrash('P2');
    emit({ type: 'op', ms: hr() - t0, ok, id: e.id });
    maybeCrash('P3');
    if (rate) await sleep(1000 / rate);
  }
  emit({ type: 'drained' }); process.exit(0);
}

async function runQueue() {
  const db = new DatabaseSync(args.db);
  db.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;');
  db.exec('CREATE TABLE IF NOT EXISTS outbox(id TEXT PRIMARY KEY, seq INTEGER, body TEXT, state INTEGER DEFAULT 0)');
  db.exec('CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v INTEGER)');
  const ins = db.prepare('INSERT INTO outbox(id,seq,body) VALUES(?,?,?)');
  const ack = db.prepare('DELETE FROM outbox WHERE id=?');
  let seq = (db.prepare("SELECT v FROM meta WHERE k='seq'").get()?.v) ?? 0;
  const setSeq = db.prepare("INSERT OR REPLACE INTO meta(k,v) VALUES('seq',?)");
  let generating = N > 0;
  const inflight = new Set();

  async function generator() {
    for (let i = 0; i < N; i++) {
      const e = makeEvent(seq);
      fs.appendFileSync(gtFile, `${e.id},${e.seq}\n`);
      const t0 = hr();
      db.exec('BEGIN'); ins.run(e.id, e.seq, JSON.stringify(e)); setSeq.run(++seq); db.exec('COMMIT');
      emit({ type: 'op', ms: hr() - t0, ok: true, id: e.id });
      if (rate) await sleep(1000 / rate);
    }
    generating = false;
  }
  async function worker() {
    let backoff = 100;
    for (;;) {
      const exclude = [...inflight];
      const rows = db.prepare(`SELECT id, body FROM outbox ${exclude.length ? `WHERE id NOT IN (${exclude.map(() => '?').join(',')})` : ''} ORDER BY seq LIMIT ?`).all(...exclude, batch);
      if (!rows.length) {
        if (!generating && inflight.size === 0) return;
        await sleep(20); continue;
      }
      rows.forEach(r => inflight.add(r.id));
      try {
        maybeCrash('P1');
        const r = await post('/sync', { device, events: rows.map(x => JSON.parse(x.body)) });
        maybeCrash('P2');
        db.exec('BEGIN'); for (const id of r.acked) ack.run(id); db.exec('COMMIT');
        maybeCrash('P3');
        emit({ type: 'acked', count: r.acked.length }); backoff = 100;
      } catch {
        // backoff exponencial com jitter completo, teto de 2 s
        await sleep(rand() * backoff); backoff = Math.min(backoff * 2, 2000);
      } finally { rows.forEach(r => inflight.delete(r.id)); }
    }
  }
  await Promise.all([generator(), ...Array.from({ length: parallel }, worker)]);
  emit({ type: 'drained' }); process.exit(0);
}
(variant === 'online' ? runOnline : runQueue)();
