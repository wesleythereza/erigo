import sys, os
from outguard import run_dir
D = run_dir('python3 pei_analysis.py runs/<RUN_ID>')
import json, collections
rows = [json.loads(l) for l in open(f'{D}/pei_http.jsonl')]
G = collections.defaultdict(list)
for r in rows: G[(r['idem'], r['unit'], r['respDrop'])].append(r)
out = []
for k, v in sorted(G.items(), key=lambda kv: (-kv[0][0], kv[0][1], kv[0][2])):
    s = lambda f: sum(x[f] for x in v)
    rec = dict(idem=k[0], unit=k[1], respDrop=k[2], trials=len(v), generated=s('generated'), lostEdits=s('lostEdits'),
               doubleApplied=s('doubleApplied'), versionGaps=s('versionGaps'), notPreserved=s('notPreserved'),
               conflicts=s('conflicts'), round1Conflicts=s('round1Conflicts'), falseConflicts=s('falseConflicts'),
               trialsFalseConflict=sum(1 for x in v if x['falseConflicts'] > 0), replays=s('replays'),
               reviewAttempts=s('reviewAttempts'), staleRejected=s('staleRejected'), resolved=s('resolved'),
               propTried=s('propTried'), propApplied=s('propApplied'), devices=s('devices'), devicesConverged=s('devicesConverged'),
               trialsAllConverged=sum(1 for x in v if x['devicesConverged'] == x['devices']),
               metasMixed=s('metasMixed'), metasIncoherent=s('metasIncoherent'), openAtEnd=s('openAtEnd'),
               trialsReview=sum(1 for x in v if x['round1Conflicts'] > 0),
               opApplied=s('opApplied'), opPreserved=s('opPreserved'), opMissing=s('opMissing'), appliedNotInHistory=s('appliedNotInHistory'),
               resGenuineStale=s('resGenuineStale'), resResentAfterApplied=s('resResentAfterApplied'), resApplied=s('resApplied'), resolutionIds=s('resolutionIds'),
               replayResolved=s('replayResolved'), replayStale=s('replayStale'), resolveLostResponses=s('resolveLostResponses'))
    for k2 in ['editSends', 'editRetransmissions', 'serverOpReplays', 'opsRecoveredFromMemo', 'resSends', 'resRetransmissions', 'serverResReplays', 'opViolations', 'unitViolations', 'units']:
        rec[k2] = sum(x.get(k2, 0) for x in v)
    out.append(rec); print(rec)
json.dump(out, open(f'{D}/pei_http_summary.json', 'w'), indent=1)
