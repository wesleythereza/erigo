'use strict';
const { spawn } = require('child_process');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { mulberry32, hashSeed } = require('./rng');
const sleep = ms => new Promise(r => setTimeout(r, ms));
let portBase = 12000 + Math.floor(Math.random() * 1000); // portas abaixo da faixa efêmera; não afetam o comportamento
const OUT = require('./outguard')(process.argv[3], 'node harness.js <S1|S2|S3|S4|S4L|S5R|S5P> runs/<RUN_ID>/raw.jsonl');
fs.mkdirSync(path.dirname(OUT), { recursive: true }); fs.mkdirSync('tmp', { recursive: true });
// aguarda o término do processo antes de apagar seus arquivos (necessário em sistemas que bloqueiam arquivos abertos)
const exited = p => (p.exitCode !== null || p.signalCode !== null) ? Promise.resolve() : new Promise(r => p.once('exit', r));

function get(port, p, body) {
  return new Promise((res) => {
    const rq = http.request({ host: '127.0.0.1', port, path: p, method: body ? 'POST' : 'GET', agent: false }, rs => {
      const c = []; rs.on('data', d => c.push(d)); rs.on('end', () => { try { res(JSON.parse(Buffer.concat(c))); } catch { res(null); } });
    }); rq.on('error', () => res(null)); rq.end(body ? JSON.stringify(body) : undefined);
  });
}
function start(script, argv) {
  return new Promise(res => { const p = spawn('node', ['--no-warnings', script, ...argv], { stdio: ['ignore', 'pipe', 'inherit'] }); p.stdout.once('data', () => res(p)); });
}
function spawnClient(argv, onMsg) {
  const p = spawn('node', ['--no-warnings', 'client.js', ...argv], { stdio: ['ignore', 'pipe', 'inherit'] });
  let buf = '';
  p.stdout.on('data', d => { buf += d; let i; while ((i = buf.indexOf('\n')) >= 0) { const l = buf.slice(0, i); buf = buf.slice(i + 1); if (l) { try { onMsg(JSON.parse(l)); } catch {} } } });
  p.done = new Promise(r => p.on('exit', (code, sig) => r(sig || code)));
  return p;
}
const pct = (a, q) => { if (!a.length) return null; const s = [...a].sort((x, y) => x - y); const i = (s.length - 1) * q; const lo = Math.floor(i), hi = Math.ceil(i); return s[lo] + (s[hi] - s[lo]) * (i - lo); };

async function trial(o) {
  const { scenario, variant, n, rate = 0, parallel = 1, faults = {}, offlineFirst = false, cycles = null, rep, param = '', timeout = 2000 } = o;
  const extra = o.extra || {};
  const seed = hashSeed(`${scenario}|${variant}|${n}|${param}|${rep}`);
  const rand = mulberry32(seed);
  const rnd = (a, b) => a + rand() * (b - a);
  const tag = `${scenario}-${variant}-${n}-${rep}-${Date.now()}`;
  if (portBase > 30000) portBase = 12000;
  const sp = portBase++, pp = portBase++, ap = portBase++;
  const sdb = `tmp/${tag}-srv.db`, cdb = `tmp/${tag}-cli.db`, gt = `tmp/${tag}.gt`;
  fs.writeFileSync(gt, '');
  const mode = variant === 'queue-naive' ? 'naive' : 'dedup';
  const server = await start('server.js', [`--port=${sp}`, `--db=${sdb}`, `--mode=${mode}`]);
  const proxy = await start('proxy.js', [`--port=${pp}`, `--target=${sp}`, `--admin=${ap}`, `--seed=${seed}`]);
  const cvariant = variant === 'online' ? 'online' : 'queue';
  const ops = []; let drainedAt = null; let restoredAt = null; const crashes = [];
  const onMsg = m => { if (m.type === 'op') ops.push(m); if (m.type === 'drained') drainedAt = m.t; if (m.type === 'crash') crashes.push(m.point); };
  const gtCount = () => fs.readFileSync(gt, 'utf8').split('\n').filter(Boolean).length;
  let clientSeed = seed;
  const baseArgs = () => [`--variant=${cvariant}`, `--db=${cdb}`, `--server=127.0.0.1:${pp}`, `--gt=${gt}`, `--parallel=${parallel}`, `--rate=${rate}`, `--timeout=${timeout}`, `--seed=${++clientSeed}`];
  await get(ap, '/', { down: offlineFirst, ...(offlineFirst ? {} : faults) });
  const crashArgs = () => extra.crashPoint ? [`--crashAt=${extra.crashPoint}`, `--crashK=${Math.ceil(rnd(0, extra.crashKMax))}`] : [];
  const pointCrashes = extra.crashPoint ? (extra.crashes || 3) : 0;
  let client = spawnClient([...baseArgs(), `--n=${n}`, ...crashArgs()], onMsg);
  let cyc = true;
  if (offlineFirst) {
    while (ops.length < n) await sleep(10);
    if (extra.offlineHold) await sleep(extra.offlineHold);
    await get(ap, '/', { down: false, ...faults }); restoredAt = Date.now();
  } else restoredAt = Date.now();
  const csleep = async ms => { const end = Date.now() + ms; while (cyc && Date.now() < end) await sleep(50); };
  let cycLoop = Promise.resolve(); let downTime = 0;
  if (cycles) cycLoop = (async () => {
    while (cyc) { await get(ap, '/', { down: false }); await csleep(rnd(...cycles.up)); if (!cyc) break;
      await get(ap, '/', { down: true }); const t0 = Date.now(); await csleep(rnd(...cycles.down)); downTime += Date.now() - t0; }
    await get(ap, '/', { down: false });
  })();
  let kills = 0;
  const restart = (withCrash) => {
    const started = gtCount();
    const remaining = variant === 'online' ? Math.max(0, n - started) : 0;
    client = spawnClient([...baseArgs(), `--n=${remaining}`, `--seqStart=${started}`, ...(withCrash ? crashArgs() : [])], onMsg);
  };
  // encerramentos aleatórios pelo orquestrador (S5R)
  for (let k = 0; k < (extra.randomKills || 0); k++) {
    await sleep(rnd(...extra.crashAfter));
    if (drainedAt) break;
    client.kill('SIGKILL'); await client.done; kills++;
    restart(false);
  }
  // encerramentos em pontos controlados (S5P): o cliente se encerra; o orquestrador reinicia
  for (let k = 0; k < pointCrashes; k++) {
    const sig = await client.done;
    if (sig !== 'SIGKILL') break;
    kills++; restart(k + 1 < pointCrashes);
  }
  const deadline = Date.now() + (extra.deadline || 120000);
  let stopWait = false;
  const code = await Promise.race([client.done, (async () => { while (!stopWait && Date.now() < deadline) await sleep(100); return 'deadline'; })()]);
  stopWait = true; cyc = false; await cycLoop; if (code === 'deadline') { client.kill('SIGKILL'); await client.done; }
  await sleep(200);
  const st = await get(sp, '/stats'); const ids = new Set(await get(sp, '/ids'));
  const gtRows = fs.readFileSync(gt, 'utf8').split('\n').filter(Boolean).map(l => { const [id, seq] = l.split(','); return { id, seq: +seq }; });
  const gtIds = gtRows.map(r => r.id);
  // verificação explícita da ordem: pares (dispositivo, sequência) esperados × recuperados
  const pairs = await get(sp, '/pairs');
  const expected = gtRows.filter(r => ids.has(r.id)).map(r => `tablet-01|${r.seq}|${r.id}`);
  const recovered = pairs.map(p => `${p.device}|${p.seq}|${p.id}`);
  const expSet = new Set(expected);
  const pairsMatched = recovered.filter(x => expSet.has(x)).length;
  const orderVerified = expected.length === recovered.length && expected.every((x, i) => x === recovered[i]);
  const lostIds = gtIds.filter(id => !ids.has(id));
  const okIds = new Set(ops.filter(x => x.ok).map(x => x.id)); const failIds = new Set(ops.filter(x => !x.ok).map(x => x.id));
  server.kill(); proxy.kill(); await Promise.all([exited(server), exited(proxy), exited(client)]);
  for (const f of fs.readdirSync('tmp')) if (f.startsWith(tag)) fs.rmSync(path.join('tmp', f), { force: true });
  const lat = ops.map(x => x.ms);
  const rec = { scenario, variant, n, param, rate, parallel, faults, rep, seed,
    scheduled: n, started: gtIds.length, acceptedLocalOrUser: okIds.size, failedNotified: failIds.size,
    confirmedServer: gtIds.length - lostIds.length, lost: lostIds.length,
    lostNotified: lostIds.filter(id => failIds.has(id)).length, lostSilent: lostIds.filter(id => !failIds.has(id)).length,
    serverNotUser: variant === 'online' ? gtIds.filter(id => ids.has(id) && !okIds.has(id)).length : null,
    duplicates: st.rows - st.distinct, outOfOrder: st.outOfOrder, requests: st.requests, bytesIn: st.bytesIn,
    procMsTotal: st.procMsTotal, procReq: st.procReq, recordsIn: st.recordsIn,
    seqComplete: new Set(st.seqs).size === st.distinct, pairsExpected: expected.length, pairsRecovered: recovered.length, pairsMatched, orderVerified,
    drainMs: drainedAt && restoredAt ? drainedAt - restoredAt : null,
    drainAfterGenMs: drainedAt && ops.length ? drainedAt - ops[ops.length - 1].t : null,
    finished: code !== 'deadline', kills, crashPoint: extra.crashPoint || null, downTimeMs: downTime,
    latP50: pct(lat, 0.5), latP95: pct(lat, 0.95), latP99: pct(lat, 0.99), opLatency: lat };
  fs.appendFileSync(OUT, JSON.stringify(rec) + '\n');
  console.error(`${scenario}${param ? '[' + param + ']' : ''} ${variant} n=${n} rep=${rep} start=${rec.started} lost=${rec.lost}(sil ${rec.lostSilent}) dup=${rec.duplicates} kills=${kills} drain=${rec.drainMs} fin=${rec.finished}`);
  return rec;
}

const VAR = ['online', 'queue-naive', 'queue-proposed'];
const Q = ['queue-naive', 'queue-proposed'];
const scenarios = {
  S1: async rep => { for (const v of VAR) await trial({ scenario: 'S1', variant: v, n: 300, rate: 50, rep }); },
  S2: async rep => { for (const n of [10, 100, 1000]) for (const v of VAR.filter(x => !(x === 'online' && (n > 100 || rep > 2)))) await trial({ scenario: 'S2', variant: v, n, offlineFirst: true, rep, extra: { offlineHold: 10000 } }); },
  S3: async rep => { for (const v of VAR) await trial({ scenario: 'S3', variant: v, n: 300, rate: 20, faults: { reqDrop: 0.05 }, cycles: { up: [1000, 3000], down: [1000, 4000] }, rep }); },
  S4: async rep => { for (const rd of [0.1, 0.3]) for (const v of VAR.filter(x => !(x === 'online' && rep > 2))) await trial({ scenario: 'S4', param: 'resp' + rd, variant: v, n: 500, parallel: 2, offlineFirst: v !== 'online', rate: v === 'online' ? 50 : 0, faults: { respDrop: rd, reqDrop: 0.05, delayMin: 0, delayMax: 300 }, rep, extra: { offlineHold: 3000 } }); },
  S4L: async rep => {
    for (const v of Q) await trial({ scenario: 'S4L', param: 'L1', variant: v, n: 500, parallel: 2, offlineFirst: true, faults: { respDrop: 0.1, reqDrop: 0.05, delayMin: 50, delayMax: 150 }, rep, extra: { offlineHold: 3000 } });
    for (const v of Q) await trial({ scenario: 'S4L', param: 'L2', variant: v, n: 500, parallel: 2, offlineFirst: true, faults: { delayMin: 1500, delayMax: 2500 }, rep, extra: { offlineHold: 3000, deadline: 240000 } });
  },
  S5R: async rep => { for (const v of VAR) await trial({ scenario: 'S5R', variant: v, n: v === 'online' ? 500 : 1000, rate: v === 'online' ? 50 : 0, offlineFirst: v !== 'online', faults: { respDrop: 0.1, delayMin: 0, delayMax: 100 }, rep, extra: { randomKills: 3, crashAfter: v === 'online' ? [1500, 3000] : [150, 600], offlineHold: 1000 } }); },
  S5P: async rep => { for (const pt of ['P1', 'P2', 'P3']) for (const v of VAR) await trial({ scenario: 'S5P', param: pt, variant: v, n: v === 'online' ? 300 : 1000, rate: v === 'online' ? 50 : 0, offlineFirst: v !== 'online', rep, extra: { crashPoint: pt, crashes: 3, crashKMax: v === 'online' ? 60 : 4, offlineHold: 500 } }); },
};
(async () => {
  const which = (process.argv[2] || 'S1').split(',');
  const reps = +(process.env.REPS || 10);
  for (const s of which) for (let r = 0; r < reps; r++) await scenarios[s](r);
})();
