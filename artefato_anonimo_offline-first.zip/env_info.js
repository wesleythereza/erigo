'use strict';
// Registro do ambiente de execução (gravado junto com os resultados de cada execução)
const os = require('os'); const { execSync } = require('child_process'); const { DatabaseSync } = require('node:sqlite');
const sh = c => { try { return execSync(c, { stdio: ['ignore', 'pipe', 'ignore'] }).toString().trim(); } catch { return null; } };
const db = new DatabaseSync(':memory:');
console.log(JSON.stringify({
  timestampUtc: new Date().toISOString(), platform: os.platform(), release: os.release(), osName: sh('. /etc/os-release && echo $PRETTY_NAME'),
  arch: os.arch(), cpuModel: os.cpus()[0]?.model, logicalCpus: os.cpus().length, totalMemGiB: +(os.totalmem() / 2 ** 30).toFixed(1),
  hypervisor: sh("lscpu | sed -n 's/^Hypervisor vendor: *//p'"), node: process.version,
  sqlite: db.prepare('SELECT sqlite_version() v').get().v, python: sh('python3 --version'),
  filesystem: sh("df -T . | awk 'NR==2{print $2}'"), docker: require('fs').existsSync('/.dockerenv')
}, null, 1));
