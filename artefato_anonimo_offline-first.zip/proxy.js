'use strict';
// Proxy HTTP com injeção de falhas controlada por uma porta administrativa
const http = require('http');
const { mulberry32 } = require('./rng');
const args = Object.fromEntries(process.argv.slice(2).map(a => a.replace(/^--/, '').split('=')));
const rand = mulberry32(+(args.seed || 1));
let cfg = { down: false, reqDrop: 0, respDrop: 0, delayMin: 0, delayMax: 0 };
const target = { host: '127.0.0.1', port: +args.target };
const sleep = ms => new Promise(r => setTimeout(r, ms));
http.createServer((req, res) => {
  const chunks = []; req.on('data', d => chunks.push(d));
  req.on('end', async () => {
    if (cfg.down || rand() < cfg.reqDrop) { req.socket.destroy(); return; }
    const d = cfg.delayMin + rand() * (cfg.delayMax - cfg.delayMin); if (d) await sleep(d);
    if (cfg.down) { req.socket.destroy(); return; }
    const up = http.request({ ...target, path: req.url, method: req.method, headers: req.headers }, ur => {
      const rc = []; ur.on('data', x => rc.push(x));
      ur.on('end', () => {
        // perda de resposta: servidor já processou, cliente não recebe confirmação
        if (cfg.down || rand() < cfg.respDrop) { req.socket.destroy(); return; }
        res.writeHead(ur.statusCode, ur.headers); res.end(Buffer.concat(rc));
      });
    });
    up.on('error', () => req.socket.destroy());
    up.end(Buffer.concat(chunks));
  });
}).listen(+args.port);
http.createServer((req, res) => {
  const c = []; req.on('data', d => c.push(d));
  req.on('end', () => { if (c.length) cfg = { ...cfg, ...JSON.parse(Buffer.concat(c)) }; res.end(JSON.stringify(cfg)); });
}).listen(+args.admin, () => console.log('ready'));
